'use strict';

angular.module('nextOrderView', ['ngRoute'])

.config(['$routeProvider', function($routeProvider) {
  $routeProvider.when('/nextOrderView', {
    templateUrl: 'template/nextOrderView.html',
    controller: 'NextOrderViewCtrl'
  });
}])

.controller('NextOrderViewCtrl', ['$scope','ajaxServices',function($scope,ajaxServices) {
     $scope.init=init;  
	 $scope.init();
     $scope.recordAvaialble=false;
	 $scope.norecord=false;
    function init(){
        ajaxServices.getNextOrder().then(successCallBack,errorCallBack);
    }
    function successCallBack(result){              
        if(angular.isDefined(result)){
            $scope.order=result;
			$scope.recordAvaialble=true;
        }else{
			$scope.recordAvaialble=false;
			 $scope.norecord=true;
		}
    }
    function errorCallBack(result){
        $scope.isError=false;
		$scope.recordAvaialble=false;
		$scope.norecord=true;
    }
}
]);


