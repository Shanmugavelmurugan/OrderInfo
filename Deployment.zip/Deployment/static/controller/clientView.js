'use strict';

angular.module('clientView', ['ngRoute'])

.config(['$routeProvider', function($routeProvider) {
  $routeProvider.when('/clientView', {
    templateUrl: 'template/clientView.html',
    controller: 'ClientViewCtrl'
  });
}])

.controller('ClientViewCtrl', ['$scope','ajaxServices',function($scope,ajaxServices) {
     
	 $scope.findOrder=findOrder;  
     $scope.recordAvaialble=false;
	 $scope.norecord=false;
    function findOrder(){
		var data={"clientId":$scope.clientId};
        ajaxServices.findOrder(data).then(successCallBack,errorCallBack);
    }
    function successCallBack(result){              
        if(angular.isDefined(result)){
            $scope.order=result;
			$scope.recordAvaialble=true;
        }else{
			$scope.recordAvaialble=false;
			 $scope.norecord=true;
		}
    }
    function errorCallBack(result){
        $scope.isError=false;
		$scope.recordAvaialble=false;
		$scope.norecord=true;
    }
	

}

]);



