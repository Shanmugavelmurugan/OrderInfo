'use strict';

angular.module('addOrder', ['ngRoute'])

.config(['$routeProvider', function($routeProvider) {
  $routeProvider.when('/addOrder', {
    templateUrl: '/static/template/addOrder.html',
    controller: 'AddOrderCtrl'
  });
}])

.controller('AddOrderCtrl', ['$scope','ajaxServices',function($scope,ajaxServices) {
     $scope.submitOrder=submitOrder;  
     $scope.isError=false;  
    function submitOrder(){
        var data={"clientId":$scope.clientId,"quantity":$scope.quantity};
		ajaxServices.postOrder(data).then(successCallBack,errorCallBack);
    }
    function successCallBack(result){
		$scope.clientId="";
			$scope.quantity=""; 
			$scope.isError=false;
        if(result.status==="1"){
            $scope.orderAdded=true;
			 $scope.isError=false;
        }else{
            $scope.orderAdded=false;
			 $scope.isError=true;
        }
    }
    function errorCallBack(result, status, header, config){
		
		$scope.orderAdded=false;
        $scope.isError=true;
    }
}]);