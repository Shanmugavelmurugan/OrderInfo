var appServices = angular.module('appServices', []);

appServices.config(['$httpProvider', function ($httpProvider) {
    $httpProvider.defaults.headers.post['Content-Type'] = 'application/json; charset=utf-8';
}]);

appServices.factory('ajaxServices',['$q','$http', function($q,$http) {
   return {
        postOrder: function(postData) {
           var deferred = $q.defer();
             $http({
                    method: "POST",
                    url: '/orderInfo/addOrders',
                    dataType:"json",
					contentType: "application/json; charset=utf-8",
                    data: postData                    
                }).success(function (data, status, headers, config) {
                        deferred.resolve(data,status);
                    }).error(function (data, status, headers, config) {                       
                            deferred.reject(data,status);                       
                    });
            
            
            return deferred.promise;
           
        },
		cancelOrder: function(postData) {
           var deferred = $q.defer();
             $http({
                    method: "POST",
                    url: '/orderInfo/cancelOrder',
                    dataType:"json",
					contentType: "application/json; charset=utf-8",
                    data: postData                    
                }).success(function (data, status, headers, config) { 						
                        deferred.resolve(data,status);
                    }).error(function (data, status, headers, config) {							
                            deferred.reject(data,status);                       
                    });
            
            
            return deferred.promise;
           
        },  
		findOrder: function(postData) {
           var deferred = $q.defer();
             $http({
                    method: "POST",
                    url: '/orderInfo/clientView',
                    dataType:"json",
					contentType: "application/json; charset=utf-8",
                    data: postData                    
                }).success(function (data, status, headers, config) {
                        deferred.resolve(data);
                    }).error(function (data, status, headers, config) {                       
                            deferred.reject(data);                       
                    });
            
            
            return deferred.promise;
           
        },
		getNextOrder: function(params) {
         var deferred = $q.defer();
           $http({
                  method: "GET",
                  url: '/orderInfo/nextOrder',
                  params: params
              }).success(function (data, status, headers, config) {
                      deferred.resolve(data);
                  }).error(function (data, status, headers, config) {                       
                          deferred.reject(data);                       
                  });
            return deferred.promise;
       },	
			
        getOrders: function(params) {
         var deferred = $q.defer();
           $http({
                  method: "GET",
                  url: '/orderInfo/listOrders',
                  params: params
              }).success(function (data, status, headers, config) {
                      deferred.resolve(data);
                  }).error(function (data, status, headers, config) {                       
                          deferred.reject(data);                       
                  });
            return deferred.promise;
       }        
   }
}]);

