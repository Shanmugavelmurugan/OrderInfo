'use strict';

angular.module('cancelOrder', ['ngRoute'])

.config(['$routeProvider', function($routeProvider) {
  $routeProvider.when('/cancelOrder', {
    templateUrl: 'template/cancelOrder.html',
    controller: 'CancelOrderCtrl'
  });
}])

.controller('CancelOrderCtrl', ['$scope','ajaxServices',function($scope,ajaxServices) {
     $scope.cancelOrder=cancelOrder;  
     $scope.isError=false; 
	$scope.orderRemoved=false;
	$scope.isNotfound=false;	
$scope.data={};
    function cancelOrder(){
        var data={"clientId":$scope.clientId};
        ajaxServices.cancelOrder(data).then(successCallBack,errorCallBack);
    }
    function successCallBack(result){ 
        
            $scope.orderRemoved=true;
			$scope.clientId="";
    }
    function errorCallBack(result){
		if(angular.isDefined(result.status)){
			if(result.status==="0"){
				$scope.isNotfound=true;
			}else{
				$scope.isError=true;
			}
		}else{
			$scope.isError=true;
		}
        
    }
}]);