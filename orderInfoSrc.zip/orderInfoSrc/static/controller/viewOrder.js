'use strict';

angular.module('viewOrder', ['ngRoute'])

.config(['$routeProvider', function($routeProvider) {
  $routeProvider.when('/viewOrder', {
    templateUrl: 'template/viewOrder.html',
    controller: 'ViewOrderCtrl'
  });
}])

.controller('ViewOrderCtrl', ['$scope','ajaxServices',function($scope,ajaxServices) {
     $scope.init=init;  
	 $scope.viewSecond=viewSecond;  
     $scope.init();  
    function init(){
        ajaxServices.getOrders().then(successCallBack,errorCallBack);
    }
    function successCallBack(result){
        $scope.orders={};        
        if(angular.isDefined(result)){
            $scope.orders=result;
        }
    }
    function errorCallBack(result){
        $scope.isError=true;
    }
	 function viewSecond(input){
         if(input){ 
			var now = moment(new Date()); //todays date
			var start = moment(input); // another date
			var duration = moment.duration(now.diff(start));
			
			


var ms = moment(now,"DD/MM/YYYY HH:mm:ss").diff(moment(start,"DD/MM/YYYY HH:mm:ss"));
var d = moment.duration(ms);
var s = Math.floor(d.asHours()) + moment.utc(ms).format(":mm:ss");
			return s;
            //return now.diff(start, 'seconds');
        }else{
            return "not available";
        }
    }
}




]);


