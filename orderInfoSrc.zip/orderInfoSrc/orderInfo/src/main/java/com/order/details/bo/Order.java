package com.order.details.bo;

import java.util.Comparator;
import java.util.Date;



public class Order {
	public Date orderDate;
	public Integer clientId;
	public Integer quantity;
	public boolean isPriority;
	public Integer queuePostion;
	/**
	 * @return the queuePostion
	 */
	public Integer getQueuePostion() {
		return queuePostion;
	}
	/**
	 * @param queuePostion the queuePostion to set
	 */
	public void setQueuePostion(Integer queuePostion) {
		this.queuePostion = queuePostion;
	}
	/**
	 * @return the isPriority
	 */
	public boolean isPriority() {
		return isPriority;
	}
	/**
	 * @param isPriority the isPriority to set
	 */
	public void setPriority(boolean isPriority) {
		this.isPriority = isPriority;
	}
	/**
	 * @return the orderId
	 */
	public Date getOrderDate() {
		return orderDate;
	}
	/**
	 * @param orderId the orderId to set
	 */
	public void setOrderDate(Date orderDate) {
		this.orderDate = orderDate;
	}
	/**
	 * @return the clientId
	 */
	public Integer getClientId() {
		return clientId;
	}
	/**
	 * @param clientId the clientId to set
	 */
	public void setClientId(Integer clientId) {
		this.clientId = clientId;
	}
	/**
	 * @return the quantity
	 */
	public Integer getQuantity() {
		return quantity;
	}
	/**
	 * @param quantity the quantity to set
	 */
	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	public String toString() {
		StringBuffer buffer = new StringBuffer();
		buffer.append("OrderDetails [quantity=");
		buffer.append(quantity);
		buffer.append(", clientId=");
		buffer.append(clientId);
		buffer.append(", orderDate=");
		buffer.append(orderDate);
		buffer.append("]");
		return buffer.toString();
	}
	public boolean equals(Object obj){
		if (obj instanceof Order) {
			Order pp = (Order) obj;
           if(pp.getClientId().equals(this.clientId)){
        	   return true;
           }else {
        	   return false;
           }
        }
		return false;
	}
	/**
	 * 
	 * 
	 *
	 */
	 public static class OrderByPriority implements Comparator<Order> {

		 @Override
			public int compare(Order o1, Order o2) {
				
				boolean f1=(int)o1.getClientId()<=1000?true:false;
				boolean f2=(int)o2.getClientId()<=1000?true:false;				
				if(f1 && f2){					
					return o1.getOrderDate().compareTo(o2.getOrderDate());					
				}else if(f1==true && f2==false){
					return -1;
				}else if(f1==false && f2==true){
					return 1;
				}else if(f1==false && f2==false){					
					return o1.getOrderDate().compareTo(o2.getOrderDate());
				}			
				return 0;
			}
	 }
	/**
	 * 
	 * order by date
	 *
	 */
    public static class OrderByDate implements Comparator<Order> {

        @Override
        public int compare(Order o1, Order o2) {
        	return o1.orderDate.compareTo(o2.orderDate);
        }
    }
}
