package com.order.details.controller;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.PriorityQueue;
import java.util.Queue;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.ValueConstants;
import org.springframework.http.ResponseEntity;
import org.springframework.web.servlet.ModelAndView;

import com.order.details.bo.Order;
import com.order.details.bo.TransactionStatus;


 
@RestController
public class OrderDetailsController{
	private Logger logger = Logger.getLogger(OrderDetailsController.class);
	
	
	/**
	 * Method used to add orders 
	 * @param order
	 * @param session
	 * @return ResponseEntity
	 * @throws OrderAlreadyExist
	 */
	@RequestMapping(value = {"/addOrders"} ,method = RequestMethod.POST)
    public  ResponseEntity<TransactionStatus> addOrders(@RequestBody Order order,HttpSession session){
		TransactionStatus ts=new TransactionStatus();	
		//Queue<Order> pq= new PriorityQueue<Order>(10,new Order.OrderByDate());
    	order.setOrderDate(new Date());    	
    	Queue<Order> orderDetails=(Queue<Order>)session.getAttribute("orderDetails");
    	if(null!=orderDetails){
    		if(orderDetails.contains(order)){
    			logger.error("Already order pending order Exist."+order);
    			ts.setMessage("Already order pending order Exist.");
    			ts.setStatus("0");
    			return new ResponseEntity<TransactionStatus>(ts, HttpStatus.CONFLICT);
    		}else{
    			logger.debug("order.getClientId()"+order.getClientId()+": re:"+((int)order.getClientId()<=1000));
    			if((int)order.getClientId()<=1000){
    				order.setPriority(true);
    			}else{
    				order.setPriority(false);
    			}
	    		orderDetails.add(order);
	    		session.setAttribute("orderDetails",orderDetails);
    		}
    	}else{
    		orderDetails=new PriorityQueue<Order>(10,new Order.OrderByPriority());
    		if((int)order.getClientId()<=1000){
				order.setPriority(true);
			}else{
				order.setPriority(false);
			}
    		orderDetails.add(order);
    		session.setAttribute("orderDetails",orderDetails);    		
    	} 
    	ts.setMessage("order added successfull.");
		ts.setStatus("1");
        return new ResponseEntity<TransactionStatus>(ts, HttpStatus.CREATED);
    }
	/**
	 * Bleow method used to list of orders in Queue.
	 * @param session
	 * @return
	 */
	 @RequestMapping(value = {"/listOrders"},method = RequestMethod.GET)
	 public ResponseEntity<List<Order>> listOrders(HttpSession session){
	    	List<Order> list=null;
	    	Queue<Order> orderDetails=(Queue<Order>)session.getAttribute("orderDetails");
	    	if(null!=orderDetails && orderDetails.size()>0){
	    		list= new ArrayList(Arrays.asList(orderDetails.toArray()));
	    		Collections.sort(list,new Order.OrderByPriority());
	    		return new ResponseEntity<List<Order>>(list, HttpStatus.OK);
	    	}    	
	        return new ResponseEntity<List<Order>>(HttpStatus.NO_CONTENT);
	  }
	/**
	 * Below method is used to cancel order.
	 * @param order
	 * @param session
	 * @return ResponseEntity
	 */
    @RequestMapping(value = {"/cancelOrder"},method = RequestMethod.POST)
    public ResponseEntity<TransactionStatus> cancelOrders(@RequestBody Order order,HttpSession session){
    	TransactionStatus ts=new TransactionStatus();
    	HttpStatus status=HttpStatus.NO_CONTENT;
    	Queue<Order> orderDetails=(Queue<Order>)session.getAttribute("orderDetails");
    	if(null!=orderDetails && orderDetails.size()>0){
    		if(orderDetails.remove(order)){
    			ts.setMessage("order Removed successfull.");
    			ts.setStatus("1");    			
    		}else{
    			ts.setMessage("order_Available");
    			ts.setStatus("0");
    			status=HttpStatus.NOT_FOUND;

    		}
    	}else{
			ts.setMessage("List_empty.");
			ts.setStatus("0");
			status=HttpStatus.NOT_FOUND;
		}    	
    	return new ResponseEntity<TransactionStatus>(ts, status);
    } 
    /**
     * Below method is used to view client specific order.
     * @param orderForm
     * @param session
     * @return
     */
    @RequestMapping(value = {"/clientView"},method = RequestMethod.POST)
    public ResponseEntity<Order> clientView(@RequestBody Order orderForm,HttpSession session){
    	Order order=null;
    	Queue<Order> orderDetails=(Queue<Order>)session.getAttribute("orderDetails");
    	if(null!=orderDetails && orderDetails.size()>0){
    		List<Order> list= new ArrayList(Arrays.asList(orderDetails.toArray()));
    		int i=1;
        	for(Order tempOrder:list){
        		tempOrder.setQueuePostion(i++);
        		if(tempOrder.equals(orderForm)){
        			order=tempOrder;
        			return new ResponseEntity<Order>(order,HttpStatus.OK);
        		}
        	}
    	}    	
    	return new ResponseEntity<Order>(HttpStatus.NOT_FOUND);
    }
    /**
     * Below method used to find next order.
     * @param session
     * @return
     */
    @RequestMapping(value = {"/nextOrder"},method = RequestMethod.GET)
    public ResponseEntity<Order> nextOrder(HttpSession session){
    	Order order=null;
    	Queue<Order> orderDetails=(Queue<Order>)session.getAttribute("orderDetails");
    	if(null!=orderDetails && orderDetails.size()>0){
    		order=orderDetails.peek();
    		return new ResponseEntity<Order>(order,HttpStatus.OK);
    	}
    	return new ResponseEntity<Order>(HttpStatus.NOT_FOUND);
    }
}